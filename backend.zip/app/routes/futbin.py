# app/routes/futbin.py
from fastapi import APIRouter, Query
from typing import Optional
from app.services.futbin_player_price import fetch_player_price
from app.crud import alerts

router = APIRouter(prefix="/futbin", tags=["futbin"])

@router.get("/price")
async def get_price(player_id: int = Query(...), slug: str = Query(...), platform: str = Query("pc")):
    """
    Example:
      GET /futbin/price?player_id=45466&slug=harry-maguire&platform=pc
    """
    result = await fetch_player_price(player_id, slug, platform)

    # اگر خطا/قیمت None بود، alert ثبت شده در داخل fetch_player_price هم وجود داره
    # اینجا صرفاً پاسخ API رو استاندارد می‌کنیم
    return {
        "player_id": player_id,
        "platform": platform,
        "price": result.get("price"),
        "raw": result.get("raw"),
        "cached": result.get("cached", False),
        "fetched_at": result.get("fetched_at"),
        "note": result.get("note"),
    }
