import React from "react";

const UserDashboard = () => {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">پروفایل کاربری</h2>
      <p>خوش آمدید به داشبورد کاربری.</p>
    </div>
  );
};

export default UserDashboard;
