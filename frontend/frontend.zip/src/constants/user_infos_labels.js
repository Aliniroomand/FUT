const user_labels = {
  id: "شناسه کاربر",
  phone_number: "شماره موبایل",
  email: "ایمیل",
  is_admin: "ادمین؟",
  first_name: "نام",
  last_name: "نام خانوادگی",
  card_number: "شماره کارت",
  bank_account_number: "شماره حساب بانکی",
  bank_account_name: "نام صاحب حساب",
  telegram_id: "آیدی تلگرام"
};

export default user_labels;
