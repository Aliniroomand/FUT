import RangeManagement from "../../../components/admin/RangeManagement/RangeManagement";

const MethodManagement = () => {
  return (
    <>
     <RangeManagement/>
    </>
  );
};

export default MethodManagement;
