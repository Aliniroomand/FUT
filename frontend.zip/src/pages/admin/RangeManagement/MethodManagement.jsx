import TransferMethod from "@/components/admin/TransferMethod"
const MethodManagement = () => {
  return (
    <>
     <TransferMethod/>
    </>
  );
};

export default MethodManagement;
