import PlayerManagement from "@/components/admin/PlayerManagement/PlayerManagement"
const PlayerManagementPage = () => {
  return (
    <>
      <PlayerManagement />
    </>
  );
};

export default PlayerManagementPage;
