import AdminEAAccountPanel from "@/components/admin/EAAcountsManagement/AdminEAAccountPanel";

const EAAccountsPage = () => {
  return <AdminEAAccountPanel />;
};

export default EAAccountsPage;
