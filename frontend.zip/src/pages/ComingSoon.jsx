import typing from "@/assets/ComingSoon.gif"

const ComingSoon= ()=>{
    
            <div className="fixed top-0 right-0 w-svw h-svh bg-red-500 ">
        <img src={typing} alt='typing' />
            <h1>Coming soon ...</h1>
            <h3>I'm Working on It ...</h3>
        </div>
}

export default ComingSoon;