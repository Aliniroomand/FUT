PROFILE_PROMPT_MSG = "لطفاً نام کامل و اطلاعات حساب بانکی خود را وارد کنید."
PROFILE_WARNING_MSG = "⚠️ دقت کنید: هرگونه اشتباه در مشخصات بانکی منجر به واریز به حساب اشتباه خواهد شد و مسئولیت بر عهده شماست."
PROFILE_CONFIRM_MSG = "آیا اطلاعات زیر را تأیید می‌کنید؟"
PROFILE_SUCCESS_MSG = "✅ اطلاعات پروفایل و تراکنش با موفقیت ثبت شد."
BUY_DISABLED_MSG = "⛔️ در حال حاضر سیستم خرید فعال نیست."
BUY_CHOOSE_METHOD_MSG = "لطفاً روش انتقال را انتخاب کنید:"
BUY_METHODS_INFO_MSG = "متد های فعالی که هست بر اساس تشخیص امنیت هوش مصنوعی + ادمین هست که با توجه به امنیت مارکت انتخاب میشه"
BUY_METHODS_ERROR_MSG = "⛔️ خطا در دریافت متدهای انتقال. لطفاً بعداً تلاش کنید."
BUY_METHOD_DISABLED_MSG = "⛔️ این روش فعلاً غیرفعال است. یکی دیگر را انتخاب کنید."


def out_of_range_text(amount: float) -> str:
	return (
		f"❌ مقدار {amount} خارج از بازه‌های قابل پردازش است.\n"
		"بهتر است این مقدار توسط ادمین بررسی شود.\n"
		"🔗 برای تماس با ادمین: @your_admin_username"
	)


def build_card_info_text(range_obj: dict, primary: dict, fallback: dict, transfer_multiplier: float, amount: float) -> str:
	def info_for(card: dict) -> str:
		estimated = card.get("estimated_value") or card.get("estimated") or 0
		approx_buy_now = estimated * transfer_multiplier
		transfer_diff = approx_buy_now - estimated
		approx_transfer = transfer_diff * 0.91  # منهای 9%
		return (
			f"نام بازیکن: {card.get('name')}\n"
			f"ارزش تخمینی کارت: {estimated}\n"
			f"بای‌نو حدودی: {int(approx_buy_now)}\n"
			f"مقدار انتقال حدودی: {int(approx_transfer)}\n"
		)

	return (
		f"✅ مقدار {amount} داخل بازه `{range_obj.get('id')}` یافت شد.\n\n"
		f"--- کارت اول (اصلی) ---\n{info_for(primary)}\n"
		f"--- کارت دوم (پشتیبان) ---\n{info_for(fallback)}\n\n"
		"لطفاً یکی از گزینه‌ها را انتخاب کنید:"
	)
