from functools import wraps
from bot.storage import token_exists
from telegram import Update
from telegram.ext import ContextTypes


def login_required(handler):
    @wraps(handler)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        user_id = user.id if user else None
        if not user_id or not token_exists(user_id):
            if update.message:
                await update.message.reply_text("❌ لطفاً ابتدا وارد شوید یا ثبت‌نام کنید.")
            elif update.effective_chat:
                await update.effective_chat.send_message("❌ لطفاً ابتدا وارد شوید یا ثبت‌نام کنید.")
            return
        return await handler(update, context, *args, **kwargs)
    return wrapper
